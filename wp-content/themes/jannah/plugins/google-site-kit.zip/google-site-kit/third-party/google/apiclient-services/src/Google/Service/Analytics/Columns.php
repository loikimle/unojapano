<?php

namespace Google\Site_Kit_Dependencies;

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
class Google_Service_Analytics_Columns extends \Google\Site_Kit_Dependencies\Google_Collection
{
    protected $collection_key = 'items';
    public $attributeNames;
    public $etag;
    protected $itemsType = 'Google\Site_Kit_Dependencies\Google_Service_Analytics_Column';
    protected $itemsDataType = 'array';
    public $kind;
    public $totalResults;
    public function setAttributeNames($attributeNames)
    {
        $this->attributeNames = $attributeNames;
    }
    public function getAttributeNames()
    {
        return $this->attributeNames;
    }
    public function setEtag($etag)
    {
        $this->etag = $etag;
    }
    public function getEtag()
    {
        return $this->etag;
    }
    /**
     * @param Google_Service_Analytics_Column[]
     */
    public function setItems($items)
    {
        $this->items = $items;
    }
    /**
     * @return Google_Service_Analytics_Column[]
     */
    public function getItems()
    {
        return $this->items;
    }
    public function setKind($kind)
    {
        $this->kind = $kind;
    }
    public function getKind()
    {
        return $this->kind;
    }
    public function setTotalResults($totalResults)
    {
        $this->totalResults = $totalResults;
    }
    public function getTotalResults()
    {
        return $this->totalResults;
    }
}
